300Tours website

Files:
- index.html: responsive one-page website.

How to preview:
1. Open index.html in a web browser.
2. An internet connection is needed to load the destination photographs from Unsplash.

How to publish:
Upload index.html to your web hosting provider's public website folder. For a domain such as 300tours.co.za, connect the domain to that hosting account.

Contact links:
WhatsApp opens https://wa.me/27729060032
Email opens mailto:info@300tours.co.za

Note: The logo is recreated as editable text and an inline vector mountain mark. Replace it with your official logo if you have one.
